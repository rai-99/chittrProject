import React, { Component } from 'react';
import { Image, Text, View, TouchableOpacity, StyleSheet, AsyncStorage, FlatList, ActivityIndicator, Button } from 'react-native';

class MyAccount extends Component {
   constructor(props) {
      super(props);
      this.state = {
         isLoading: true,
         myDetails: [],
         TOKEN: ' ',
         ID: [],
         newProfilePic: 'https://lh3.googleusercontent.com/proxy/m4wK9ato-i2DqPZk2eCIAcMgLkvQadKvWQ8hbRrGkAVXZThmDNPKoGTH9mQlaLQGtMBPue7NkgzXkz4XG5wAZokjEmUUHmpk3PZ8NZVmRuXGZiT44Q',
         imageString: 'https://camo.githubusercontent.com/341831200626efe3e0cf83317801fcac2200fbe2/68747470733a2f2f662e636c6f75642e6769746875622e636f6d2f6173736574732f323639323831302f323130343036312f34643839316563302d386637362d313165332d393230322d6637333934306431306632302e706e67' //default blank image

      };
   }

   componentDidMount() {
      this.getToken();
   }

   getToken = async () => {
      try {
         let res = await AsyncStorage.getItem('@logInResponse:token');
         let res2 = await AsyncStorage.getItem('@logInResponse:id');
         this.setState({
            TOKEN: res,
            ID: res2
         });
         this.getMyDetails()
         this.getAccountPhoto()
         console.log("Token is  :", this.state.ID);
      } catch (error) {
         console.log("GET TOKEN ERROR : " + error);
      }
   }

   getMyDetails() {
      return fetch('http://10.0.2.2:3333/api/v0.0.5/user/' + parseInt(this.state.ID),
         {
            method: 'GET',
            headers: {
               'Content-Type': 'application/json',
            },
         })
         .then((response) => response.json())
         .then((responseJson) => {
            this.setState({
               myDetails: [responseJson],
               isLoading: false,
            });
            console.log("The server response is :" + JSON.stringify(this.state.myDetails))
         })
         .catch((error) => {
            console.log("ERROR" + error);
         });
   }

   getAccountPhoto() {
      return fetch('http://10.0.2.2:3333/api/v0.0.5/user/3/photo', //needs changing 
         {
            method: 'GET',
            headers: {
               'X-Authorization': this.state.TOKEN,
               'Content-Type': 'image/png',
            },
         })
         .then((response) => response.json())
         .then((responseJson) => {
            console.log(responseJson)
            alert(responseJson)
            this.setState({
               imageString: responseJson
            });
            console.log("THE GET PHOTO RESPONSE:" + this.state.imageString);
         })
         .catch((error) => {
            console.log("GET ACCOUNT PHOTO ERROR :" + error);
         });
   }

   async logout() {
      try {
         fetch("http://10.0.2.2:3333/api/v0.0.5/logout",
            {
               method: 'POST',
               headers: {
                  'X-Authorization': this.state.TOKEN
               },
            });
         alert("Logout Successful!")
         this.props.navigation.navigate('LogInscreen')
      }
      catch (error) {
         console.error(error);
      }
   }

   uploadNewPic() {
      try {
         fetch("http://10.0.2.2:3333/api/v0.0.5/user/photo",
            {
               method: 'POST',
               headers: {
                  'X-Authorization': this.state.TOKEN,
                  'Content-Type': 'application/x-www-form-urlencoded'
               },
               body: this.state.newProfilePic
            });
         alert("Upload succesful")
      }
      catch (error) {
         console.error(error);
      }
   }


   render() {
      if (this.state.isLoading) {
         return (
            <View>
               <ActivityIndicator />
            </View>);
      }

      return (
         <View style={styles.container}>
            <Text style={styles.TitleText}> MY ACCOUNT </Text>
            <Image
               style={styles.userPhoto}
               source={{ uri: this.state.imageString }} />

            <TouchableOpacity
               onPress=
               {
                  () => this.uploadNewPic()
               }>
               <Text style={styles.TitleText2}> Change profile pic </Text>
            </TouchableOpacity>


            <FlatList
               refreshing={this.state.isLoading}
               onRefresh={this.getToken}
               data={this.state.myDetails}
               keyExtractor={({ user_id }) => user_id}
               renderItem={({ item }) => (
                  <View style={styles.list}>
                     <Text style={styles.ListText}>{'Name :  ' + item.given_name + " " + item.family_name}</Text>
                     <Text style={styles.ListText}>{'Email :  ' + item.email}</Text>
                  </View>
               )}
            />

            <Text style={styles.TitleText2}> My recent chits: </Text>
            <FlatList
               refreshing={this.state.isLoading}
               onRefresh={this.getToken}
               data={this.state.myDetails[0].recent_chits}
               keyExtractor={({ chit_id }) => chit_id}
               renderItem={({ item }) => <View style={styles.list}>
                  <Text style={styles.ListText}>{item.chit_content}</Text>
               </View>} />

            <TouchableOpacity
               style={styles.Button}
               onPress=
               {
                  () => this.props.navigation.navigate('EditAccount')
               }>
               <Text style={styles.ButtonText}> Edit account </Text>
            </TouchableOpacity>

            <TouchableOpacity
               style={styles.Button}
               onPress=
               {
                  () => this.logout()
               }>
               <Text style={styles.ButtonText}> Logout </Text>
            </TouchableOpacity>


         </View>

      );
   }

}

export default MyAccount
const styles = StyleSheet.create({
   container: {
      flex: 1,
      backgroundColor: '#FFFFFF'
   },

   userPhoto: {
      alignContent: "center",
      width: 95,
      height: 125,
      marginLeft: "auto",
      marginRight: "auto"
   },

   ButtonText: {
      color: 'white',
      fontSize: 28,
      fontWeight: 'bold'
   },

   TitleText: {
      color: 'black',
      fontSize: 28,
      fontWeight: 'bold',
      textAlign: "center",
      margin: 15
   },

   TitleText2: {
      color: 'black',
      fontSize: 20,
      fontWeight: 'bold',
      textAlign: "center",
   },


   ListText: {
      color: 'black',
      borderRadius: 15,
      fontSize: 20,
      textAlign: "center",
      backgroundColor: "#F5F5F5",
      alignItems: 'center',
      margin: 5,
      borderColor: 'black',
      borderWidth: 2,
   },

   Button: {
      backgroundColor: '#233947',
      borderRadius: 15,
      alignItems: 'center',
      margin: 6,
      height: 50,
   },

});