import React, { Component } from 'react';
import { Text, View, StyleSheet, FlatList, Alert, ActivityIndicator, TouchableOpacity, AsyncStorage } from 'react-native';

class UserPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      TOKEN: '',
      ID: '',
      allMyFollowings: [],
    };
  }

  getToken = async () => {
    try {
      let res = await AsyncStorage.getItem('@logInResponse:token');
      let res2 = await AsyncStorage.getItem('@logInResponse:id');

      this.setState({
        TOKEN: res,
        ID: res2
      });
      this.getMyFollowings()
      console.log("Get token working : " + this.state.ID)
    } catch (error) {
      console.log("GET TOKEN ERROR : " + error);
    }
  }


  getMyFollowings() {
    return fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + +this.state.ID + "/following",
      {
        method: 'GET'
      })
      .then((response) => response.json())
      .then((responseJson) => {
        this.setState({
          isLoading: false,
          allMyFollowings: responseJson,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  }


  componentDidMount() {
    this.getToken()


  }

  render() {
    if (this.state.isLoading) {
      return (
        <View>
          <ActivityIndicator />
        </View>)
    }

    return (
      <View style={styles.container}>
        <Text style={styles.TitleText}>My following</Text>
        <FlatList
          refreshing={this.state.isLoading}
          onRefresh={this.getToken}
          data={this.state.allMyFollowings}
          keyExtractor={({ user_id }) => user_id}
          renderItem={({ item }) => <View style={styles.list}>
            <Text style={styles.ListText}>{'Name :  ' + item.given_name + " " + item.family_name}</Text>
          </View>} />
      </View>
    );
  }
}



export default UserPage

const styles = StyleSheet.create({
  container: {
    flex: 2,
    backgroundColor: '#FFFFFF'
  },

  ButtonText: {
    color: 'white',
    fontSize: 28,
    fontWeight: 'bold'
  },

  TitleText: {
    color: 'black',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: "center",
    margin: 15
  },

  ListText: {
    color: 'black',
    borderRadius: 15,
    fontSize: 18,
    textAlign: "center",
    backgroundColor: "#F5F5F5",
    alignItems: 'center',
    margin: 10,
    borderColor: 'black',
    borderWidth: 2,
  },

  Button: {
    backgroundColor: '#233947',
    borderRadius: 15,
    alignItems: 'center',
    margin: 5,
    height: 50,
  },
});