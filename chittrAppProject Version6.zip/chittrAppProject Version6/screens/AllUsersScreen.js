import React, { Component } from 'react';
import { Text, View, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity, TextInput, AsyncStorage } from 'react-native';


class AllUsersScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: true,
            userDetails: [],
            followID: 0,
            ID: 0,
            TOKEN: '',
            followID:''
        }
    }

    setClickedID = async () => { //sets the login user id and token in async storage
        try {
         AsyncStorage.setItem('@clickedUser:id', "" + this.state.followID)
          console.log("Search info  is : "+ this.state.followID)
          this.props.navigation.push('UserPage')
        } catch (e) {
          console.log("setClickedID function error : ", e); //error message catch
        }
      }

    storeSearchID(id){
        try {
            this.state.followID = id
            console.log("Storing is working");
            this.setClickedID();  
        } catch (e) {
            console.log("Eror : ", e); //error message catch
        }
    }
    

    getToken = async () => {
        try {
           let res = await AsyncStorage.getItem('@logInResponse:token');
           let res2 = await AsyncStorage.getItem('@logInResponse:id');
           console.log("Token is  :", res + "     id is :" + res2);
           this.setState({
              TOKEN: res,
              ID: res2
           });
        } catch (error) {
           console.log("GET TOKEN ERROR : " + error);
        }
     }

    storeUserFollowID(id) {
        try {
            this.state.followID = id
            console.log("Search info  is : "+ this.state.followID);
            this.followUser();
            
        } catch (e) {
            console.log("Set function error : ", e); //error message catch
        }
    }

    storeUserUnFollowID(id) {
        try {
            this.state.followID = id
            console.log("Search info  is : "+ this.state.followID);
            this.UnfollowUser();
            
        } catch (e) {
            console.log("Set function error : ", e); //error message catch
        }
    }

    followUser() {
        try{
          fetch("http://10.0.2.2:3333/api/v0.0.5/user/"+this.state.followID+"/follow",
          {
            method: 'POST',
            headers: {
              'X-Authorization': this.state.TOKEN
            },
            });
            console.log("Follow function working! This user id is now being followed :" + this.state.followID )
          }
        catch (error) {
            console.error(error);
          }
    }

    
    UnfollowUser() {
        try{
          fetch("http://10.0.2.2:3333/api/v0.0.5/user/"+this.state.followID+"/follow",
          {
            method: 'DELETE',
            headers: {
              'X-Authorization': this.state.TOKEN
            },
            });
            console.log("Un follow function working! This user id is now been unfollowed :" + this.state.followID )
          }
        catch (error) {
            console.error(error);
          }
    }

    showAllUsers() {
        return fetch('http://10.0.2.2:3333/api/v0.0.5/search_user/?q=@')
            .then((response) => response.json())
            .then((responseJson) => {
                this.setState({
                    isLoading: false,
                    userDetails: responseJson,
                });
            })
            .catch((error) => {
                console.error(error);
            });
    }

    componentDidMount() {
        this.showAllUsers();
        this.getToken();
    }

    render() {
        if (this.state.isLoading) {
            return (
                <View>
                    <ActivityIndicator />
                </View>)
        }

        return (
            <View style={styles.container}>
                <Text style={styles.TitleText}>Current users </Text>
                <FlatList
                    // refreshing={this.state.refresh}
                    data={this.state.userDetails}
                    keyExtractor={({ user_id }) => user_id}
                    renderItem={({ item }) =>
                        
                        <View style={styles.list}>
                            <Text style={styles.ListText}>{'Name :  ' + item.given_name + " " + item.family_name + " Email :" + item.email}</Text>
                            
                            <TouchableOpacity style={styles.Button} onPress = {() => this.storeUserFollowID(item.user_id)}>
                                <Text style={styles.ButtonText2}> FOLLOW</Text>
                            </TouchableOpacity>

                            <TouchableOpacity style={styles.Button} onPress = {() => this.storeUserUnFollowID(item.user_id)}>
                                <Text style={styles.ButtonText2}>UNFOLLOW</Text>
                            </TouchableOpacity>
                        
                            <TouchableOpacity style={styles.Button} onPress = {() => this.storeSearchID(item.user_id)}>
                                <Text style={styles.ButtonText2}>GO TO PROFILE</Text>
                            </TouchableOpacity>
                           
                        
                        
                        </View>} />
            </View>
        );
    }
}

export default AllUsersScreen
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FFFFFF',
    },
    
    ButtonText2: {
        color: 'white',
        fontSize: 20,
        textAlign: "center",
        fontWeight: 'bold'
    },

    TitleText: {
        color: 'black',
        fontSize: 28,
        fontWeight: 'bold',
        margin: 5,
        textAlign: "center"
    },

    ListText: {
        color: 'black',
        fontSize: 18,
        textAlign: "center",
        margin: 2,
        padding: 2,
    },

    Button: {
        backgroundColor: '#233947',
        alignItems: 'center',
        margin: 5,
        borderRadius: 15,
        flex: 1,
    },

    list: {
        margin: 5,
        backgroundColor: '#F5F5F5',
        borderRadius: 15,
        borderWidth: 2,
        justifyContent: 'space-around',
        elevation: 1
    },
});