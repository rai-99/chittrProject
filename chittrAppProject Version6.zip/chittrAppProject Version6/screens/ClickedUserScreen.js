import React, { Component } from 'react';
import { Image, Text, View, TouchableOpacity, StyleSheet, AsyncStorage, FlatList, ActivityIndicator, Button } from 'react-native';

class ClickedUserScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: true,
            userDetails: [],
            TOKEN: ' ',
            ID: '',
            imageString: 'https://camo.githubusercontent.com/341831200626efe3e0cf83317801fcac2200fbe2/68747470733a2f2f662e636c6f75642e6769746875622e636f6d2f6173736574732f323639323831302f323130343036312f34643839316563302d386637362d313165332d393230322d6637333934306431306632302e706e67' //default blank image

        };
    }

    componentDidMount() {
        this.getToken();
    }

    getToken = async () => {
        try {
            let res = await AsyncStorage.getItem('@logInResponse:token');
            let res2 = await AsyncStorage.getItem('@logInResponse:id');
            this.setState({
                TOKEN: res,
                ID: res2
            });
            this.getUserDetails()
            //this.getAccountPhoto()
            console.log("ID  :", this.state.ID);
        } catch (error) {
            console.log("GET TOKEN ERROR : " + error);
        }
    }

    getUserDetails() {
        return fetch('http://10.0.2.2:3333/api/v0.0.5/user/' + parseInt(this.state.ID),
            {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            })
            .then((response) => response.json())
            .then((responseJson) => {
                this.setState({
                    userDetails: [responseJson],
                    isLoading: false,
                });
                console.log("The server response is :" + JSON.stringify(this.state.userDetails))
            })
            .catch((error) => {
                console.log("ERROR" + error);
            });
    }

    followUser() {
        try {
            fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.state.followID + "/follow",
                {
                    method: 'POST',
                    headers: {
                        'X-Authorization': this.state.TOKEN
                    },
                });
            console.log("Follow function working! This user id is now being followed :" + this.state.followID)
        }
        catch (error) {
            console.error(error);
        }
    }


    UnfollowUser() {
        try {
            fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.state.followID + "/follow",
                {
                    method: 'DELETE',
                    headers: {
                        'X-Authorization': this.state.TOKEN
                    },
                });
            console.log("Un follow function working! This user id is now been unfollowed :" + this.state.followID)
        }
        catch (error) {
            console.error(error);
        }
    }

    //    getAccountPhoto() {
    //       return fetch('http://10.0.2.2:3333/api/v0.0.5/user/' + this.state.ID + '/photo', //needs changing 
    //          {
    //             method: 'GET',
    //             headers: {
    //                'X-Authorization': this.state.TOKEN,
    //                'Content-Type': 'image/png',
    //             },
    //          })
    //          .then((response) => {
    //             console.log(response)
    //             alert(response)
    //             this.setState({
    //                imageString: response
    //             });
    //             console.log("THE GET PHOTO RESPONSE:" + this.state.imageString)
    //          })
    //          .catch((error) => {
    //             console.log("GET ACCOUNT PHOTO ERROR :" + error);
    //          });
    //    }


    render() {
        if (this.state.isLoading) {
            return (
                <View>
                    <ActivityIndicator />
                </View>);
        }

        return (
            <View style={styles.container}>
                <Text style={styles.TitleText}> USER'S ACCOUNT </Text>
                <Image
                    style={styles.userPhoto}
                    source={{ uri: this.state.imageString }} />


                <FlatList
                    refreshing={this.state.isLoading}
                    onRefresh={this.getToken}
                    data={this.state.userDetails}
                    keyExtractor={({ user_id }) => user_id}
                    renderItem={({ item }) => (
                        <View style={styles.list}>
                            <Text style={styles.ListText}>{'Name :  ' + item.given_name + " " + item.family_name}</Text>
                            <Text style={styles.ListText}>{'Email :  ' + item.email}</Text>
                        </View>
                    )}
                />

                <Text style={styles.TitleText2}> Their recent chits: </Text>
                <FlatList
                    refreshing={this.state.isLoading}
                    onRefresh={this.getToken}
                    data={this.state.userDetails[0].recent_chits}
                    keyExtractor={({ chit_id }) => chit_id}
                    renderItem={({ item }) => <View style={styles.list}>
                        <Text style={styles.ListText}>{item.chit_content}</Text>
                    </View>} />

                <TouchableOpacity
                    style={styles.Button}
                    onPress=
                    {
                        () => this.props.navigation.navigate('LoggedInTab')
                    }>
                    <Text style={styles.ButtonText}> Edit account </Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.Button} onPress={() => this.storeUserFollowID(item.user_id)}>
                    <Text style={styles.ButtonText2}> FOLLOW</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.Button} onPress={() => this.storeUserUnFollowID(item.user_id)}>
                    <Text style={styles.ButtonText2}>UNFOLLOW</Text>
                </TouchableOpacity>
            </View>


        );
    }

}

export default ClickedUserScreen
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FFFFFF'
    },

    userPhoto: {
        alignContent: "center",
        width: 95,
        height: 125,
        marginLeft: "auto",
        marginRight: "auto"
    },

    ButtonText: {
        color: 'white',
        fontSize: 28,
        fontWeight: 'bold'
    },

    TitleText: {
        color: 'black',
        fontSize: 28,
        fontWeight: 'bold',
        textAlign: "center",
        margin: 15
    },

    TitleText2: {
        color: 'black',
        fontSize: 20,
        fontWeight: 'bold',
        textAlign: "center",
    },


    ListText: {
        color: 'black',
        borderRadius: 15,
        fontSize: 20,
        textAlign: "center",
        backgroundColor: "#F5F5F5",
        alignItems: 'center',
        margin: 5,
        borderColor: 'black',
        borderWidth: 2,
    },

    Button: {
        backgroundColor: '#233947',
        borderRadius: 15,
        alignItems: 'center',
        margin: 6,
        height: 50,
    },

});