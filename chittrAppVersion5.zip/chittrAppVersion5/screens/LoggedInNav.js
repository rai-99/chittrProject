import React from 'react';
import { createAppContainer } from 'react-navigation';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createStackNavigator } from 'react-navigation-stack';
import MyChits from './MyChitsScreen';
import MyAccount from './MyAccountScreen';
import AllUsers from './AllUsersScreen';
import Following from './MyFollowingScreen';
import HomeScreen from './LoginScreen';
import EditAccountScreen from './EditMyAccountScreen';
import Icon from 'react-native-vector-icons/Ionicons';
import Icon2 from 'react-native-vector-icons/MaterialIcons';
import Icon3 from 'react-native-vector-icons/AntDesign';
import Icon4 from 'react-native-vector-icons/SimpleLineIcons';


const LoggedInTab = createBottomTabNavigator(
   {
      My_Account: {
         screen: MyAccount,
         navigationOptions: () => ({   
            title: "My Account",
            tabBarOptions:{
              activeBackgroundColor:'#233947',
              inactiveBackgroundColor: '#D0D0D0',
              activeTintColor: 'white',
              inactiveTintColor: '#2d2d2d'
            },
            tabBarIcon: ({tintColor}) => (
                <Icon2
                    name="account-circle"
                    color={tintColor}
                    size={28}
                />
            )
        })
      },

      My_Following: { 
         screen: Following ,
         navigationOptions: () => ({   
            title:"Following",
            tabBarOptions:{
              activeBackgroundColor:'#233947',
              inactiveBackgroundColor: '#D0D0D0',
              activeTintColor: 'white',
              inactiveTintColor: '#2d2d2d'
            },
            tabBarIcon: ({tintColor}) => (
                <Icon4
                    name="user-following"
                    color={tintColor}
                    size={26}
                />
            )
        })
      },

      All_users: {
        screen: AllUsers,
        navigationOptions: () => ({   
           title: "All users",
           tabBarOptions:{
             activeBackgroundColor:'#233947',
             inactiveBackgroundColor: '#D0D0D0',
             activeTintColor: 'white',
             inactiveTintColor: '#2d2d2d'
           },
           tabBarIcon: ({tintColor}) => (
               <Icon
                   name="ios-people"
                   color={tintColor}
                   size={26}
               />
           )
       })
     },

      My_Chits: {
         screen: MyChits,
         navigationOptions: () => ({   
            title: "Chiting",
            tabBarOptions:{
              activeBackgroundColor:'#233947',
              inactiveBackgroundColor: '#D0D0D0',
              activeTintColor: 'white',
              inactiveTintColor: '#2d2d2d'
            },
            tabBarIcon: ({tintColor}) => (
                <Icon3
                    name="form"
                    color={tintColor}
                    size={26}
                />
            )
        })
      },


   },
   {
      navigationOptions: () => {
        return {
         headerShown: false,
        };
      }
    }
);

const LoggedInStackNav = createStackNavigator({
   LoggedInTab: LoggedInTab,
   Home: { screen: HomeScreen },
   EditAccount : {screen: EditAccountScreen,
    navigationOptions: () => {
      return {
       headerShown: false,
      };
    } 
  }
    ,
   }
 );


const AppContainer2 = createAppContainer(LoggedInStackNav);
export default AppContainer2;


