import React, { Component } from 'react';
import { Text, View, TouchableOpacity, StyleSheet, TextInput, AsyncStorage, FlatList, Image, ActivityIndicator, Button } from 'react-native';

class MyAccount extends Component {
   constructor(props) {
      super(props);
      this.state = {
         isLoading: true,
         myDetails: '',
         TOKEN: ' ',
         ID: 0 ,
         imageString: 'https://www.cetaad.org/sites/default/files/inline-images/avatar-placeholder.png' //default blank image
      };
   }

   componentDidMount() {
      this.getToken();
      this.getMyDetails();
   }

   getToken = async () => {
      try {
         let res2 = await AsyncStorage.getItem('@logInResponse:id');
         this.setState({ ID: res2 });
         console.log("Token is  :", this.state.ID);
      } catch (error) {
         console.log("GET TOKEN ERROR : " + error);
      }
   }

   getMyDetails() {
      return fetch('http://10.0.2.2:3333/api/v0.0.5/user/' + parseInt(this.state.ID),  
         {
            method: 'GET',
            headers: {
               'Content-Type': 'application/json',
            },
         })
         .then((response) => response.json())
         .then((responseJson) => {
            this.setState({
               myDetails: [responseJson],
               isLoading: false,
            });
            // let obj = this.state.myDetails;// let arr = [obj]; console.log("The array is :" + arr)
            console.log("The server response is :" + JSON.stringify(this.state.myDetails))
         })
         .catch((error) => {
            console.log(error);
         });
   }

   getAccountPhoto() {
      return fetch('http://10.0.2.2:3333/api/v0.0.5/user/7/photo', //needs changing 
         {
            method: 'GET',
            headers: {
               'Content-Type': 'image/png',
            },
         })
         .then((response) => {
            console.log(response)
            alert(response)
            this.setState({
               imageString: response
            });
            console.log(this.state.imageString)
         })
         .catch((error) => {
            console.log("getaccount photo error :" + error);
         });
   }

   async logout() {
      try {
         fetch("http://10.0.2.2:3333/api/v0.0.5/logout",
            {
               method: 'POST',
               headers: {
                  'X-Authorization': this.state.TOKEN
               },
            });
         alert("Logout Successful!")
         this.props.navigation.navigate('Home')
      }
      catch (error) {
         console.error(error);
      }
   }



   render() {
      if (this.state.isLoading) {
         return (
            <View>
               <ActivityIndicator />
            </View>);
      }

      return (
         <View style={styles.container}>
            <Text style={styles.TitleText}> MY ACCOUNT </Text>
            <Image
               style={styles.userPhoto}
               source={{ uri: this.state.imageString }} />

            <FlatList
               data={this.state.myDetails}
               keyExtractor={({ user_id }) => user_id}
               renderItem={({ item }) => (
                  <View style={styles.list}>
                     <Text style={styles.ListText}>{'Name :  ' + item.given_name + " " + item.family_name}</Text>
                  </View>
               )}
            />

            <TouchableOpacity
               style={styles.Button}
               onPress=
               {
                  () => this.props.navigation.navigate('EditAccount')
               }>
               <Text style={styles.ButtonText}> Edit account </Text>
            </TouchableOpacity>

            <TouchableOpacity
               style={styles.Button}
               onPress=
               {
                  () => this.logout()
               }>
               <Text style={styles.ButtonText}> Logout </Text>
            </TouchableOpacity>


         </View>

      );
   }

}

export default MyAccount
const styles = StyleSheet.create({
   container: {
      flex: 1,
      backgroundColor: '#FFFFFF'
   },

   userPhoto: {
      alignContent: "center",
      width: 150,
      height: 150,
      marginLeft: "auto",
      marginRight: "auto"
   },

   ButtonText: {
      color: 'white',
      fontSize: 28,
      fontWeight: 'bold'
   },

   TitleText: {
      color: 'black',
      fontSize: 28,
      fontWeight: 'bold',
      textAlign: "center",
      margin: 15
   },

   ListText: {
      color: 'black',
      borderRadius: 15,
      fontSize: 18,
      textAlign: "center",
      backgroundColor: "#F5F5F5",
      alignItems: 'center',
      margin: 10,
      borderColor: 'black',
      borderWidth: 2,
   },

   Button: {
      backgroundColor: '#233947',
      borderRadius: 15,
      alignItems: 'center',
      margin: 6,
      height: 50,
   },
});