import React, { Component } from 'react';
import { Text, View, StyleSheet, AsyncStorage, Image, ActivityIndicator, FlatList,TouchableOpacity, Alert } from 'react-native';

class SearchedUser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      userID: [],
      userGivenName: '',
      userFamilyName: '',
      userDetails: [],
      ID: 0,
      TOKEN: '',
      allFollowers: [],
      imageString: 'https://camo.githubusercontent.com/341831200626efe3e0cf83317801fcac2200fbe2/68747470733a2f2f662e636c6f75642e6769746875622e636f6d2f6173736574732f323639323831302f323130343036312f34643839316563302d386637362d313165332d393230322d6637333934306431306632302e706e67' //default blank image
    }
  }

  componentDidMount() {
    this.getLoggedInUserDetails();//gets token of logged in user
    this.getClickUserDetails();//runs the function that gets the info of the clicked user
  }

  getLoggedInUserDetails = async () => { //gets the logged in users token and ID
    try {
      let res = await AsyncStorage.getItem('@logInResponse:token');
      let res2 = await AsyncStorage.getItem('@logInResponse:id');
      console.log("Token is  :", res + "     id is :" + res2);
      this.setState({
        TOKEN: res,
        ID: res2
      });
    } catch (error) {
      console.log("GET TOKEN ERROR : " + error);
    }
  }

  getClickUserDetails = async () => { //gets clicked users id and name and stores them in states
    try {
      let res = await AsyncStorage.getItem('@clickedUserid');
      let res2 = await AsyncStorage.getItem('@clickedUsergiven_name');
      let res3 = await AsyncStorage.getItem('@clickedUserfamily_name');
      this.setState({
        userID: res,
        userGivenName: res2,
        userFamilyName: res3
      });
      this.getUserDetails()//rund the GET user details
      console.log("Selected users info  :", this.state.userID + "" + this.state.userGivenName + "" + this.state.userFamilyName);
    } catch (error) {
      console.log("getLoggedInUserDetails : " + error);
    }
  }

  getUserDetails() {//GETs the selected user's information
    return fetch('http://10.0.2.2:3333/api/v0.0.5/user/' + parseInt(this.state.userID),
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    })
    .then((response) => response.json())
    .then((responseJson) => {
      this.setState({
        userDetails: [responseJson],
      });
      this.getUserFollowers()
      console.log("The GET response is :" + JSON.stringify(this.state.userDetails))
    })
    .catch((error) => {
      console.log("ERROR:" + error);
    });
  }

  getUserFollowers() { //GETs all the users that are following this user
    return fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.state.userID + "/followers",
    {
      method: 'GET'
    })
    .then((response) => response.json())
    .then((responseJson) => {
      this.setState({
        isLoading: false,
        allFollowers: responseJson,
        isLoading: false, //set to false, so everthing renders
      });
    })
    .catch((error) => {
      console.log(error);
    });
  }

  followUser() { //POST method that follows the user that was clicked
    try{
      fetch("http://10.0.2.2:3333/api/v0.0.5/user/"+ this.state.userID +"/follow",
      {
        method: 'POST',
        headers: {
          'X-Authorization': this.state.TOKEN //the logged in user's token , so authenticate the follow
        },
      });
      Alert.alert("You are following that user now!")
      console.log("Follow function working! This user id is now being followed :" + this.state.followID )
    }
    catch (error) {
      console.error(error);
    }
  }

  render() {
    if (this.state.isLoading) {
      return (
        <View>
        <ActivityIndicator />
        </View>);
      }
      return (
        <View style={styles.container}>
        <Image
        style={styles.userPhoto}
        source={{ uri: this.state.imageString }} />
        <Text style={styles.TitleText}>{this.state.userGivenName}  {this.state.userFamilyName}</Text>
        <Text style={styles.TitleText3}> The users recent chits: </Text>

        <FlatList
        refreshing={this.state.isLoading}
        onRefresh={this.getLoggedInUserDetails}
        data={this.state.userDetails[0].recent_chits}
        keyExtractor={({ chit_id }) => chit_id}
        renderItem={({ item }) => <View style={styles.list}>
        <Text style={styles.ListText}>{item.chit_content}</Text>
        </View>} />

        <TouchableOpacity style={styles.Button} onPress={() => this.followUser()}>
        <Text style={styles.ButtonText}> FOLLOW</Text>
        </TouchableOpacity>

        <Text style={styles.TitleText3}> Their Followers : </Text>
        <FlatList
        refreshing={this.state.isLoading}
        onRefresh={this.getLoggedInUserDetails}
        data={this.state.allFollowers}
        keyExtractor={({ user_id }) => user_id}
        renderItem={({ item }) => <View style={styles.list}>
        <Text style={styles.ListText}>{'Name :  ' + item.given_name + " " + item.family_name}</Text>
        <Text style={styles.ListText}>{'Email :  ' + item.email}</Text>
        </View>} />
        </View>
      );
    }
  }

  export default SearchedUser
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#FFFFFF',
    },
    userPhoto: {
      marginTop: 20,
      alignContent: "center",
      width: 95,
      height: 125,
      marginLeft: "auto",
      marginRight: "auto"
    },
    chitText: {
      color: 'black',
      fontSize: 18,
      borderRadius: 15,
      height: 70,
      backgroundColor: "#FFFFE0",
      borderColor: 'black',
      borderWidth: 2,
    },

    ButtonText: {
      color: 'white',
      fontSize: 25,
      textAlign: "center",
      fontWeight: 'bold'
    },

    TitleText: {
      color: 'black',
      fontSize: 22,
      fontWeight: 'bold',
      margin: 5,
      textAlign: "center"
    },

    TitleText3: {
      color: 'black',
      fontSize: 20,
      textAlign: "center"
    },

    ListText: {
      color: 'black',
      fontSize: 18,
      textAlign: "center",
      margin: 2,
      padding: 2,
    },

    Button: {
      backgroundColor: '#233947',
      padding: 5,
      alignItems: 'center',
      margin: 15,
      borderRadius: 15,
      height: 50,
    },

    list: {
      margin: 5,
      backgroundColor: '#FFFFE0',
      borderRadius: 15,
      borderWidth: 2,
      justifyContent: 'space-around',
      elevation: 1
    },
  });
