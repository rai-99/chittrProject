import React, { Component } from 'react';
import { Text, View, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity, TextInput, AsyncStorage, Alert } from 'react-native';


class AllUsersScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      userDetails: [],
      followID: 0,
      ID: 0,
      TOKEN: '',
      followID: '',
      clickedGivName: '',
      clickedFamName: '',
    }
  }

  storeClickedUsersInfoAsync = async () => { //stores the clicked users info in async storage so it can be used in another screen 
    try {
      await AsyncStorage.setItem('@clickedUserid', "" + this.state.followID)
      await AsyncStorage.setItem('@clickedUsergiven_name', "" + this.state.clickedGivName)
      await AsyncStorage.setItem('@clickedUserfamily_name', "" + this.state.clickedFamName)
      console.log("Async storage success! Information that are being stored:"+ "" + this.state.followID+ ""+ this.state.clickedGivName + ""+this.state.clickedFamName)
      this.props.navigation.push('UserPage')
    } catch (e) {
      console.log("setClickedID function error : ", e); //error message catch
    }
  }

  storeSearchUserInfo(user_id, given_name, family_name) { //stores the info of the user that was clicked in states
    try {
      this.state.followID = user_id
      this.state.clickedGivName = given_name
      this.state.clickedFamName = family_name
      console.log("Storing clicked users info...");
      this.storeClickedUsersInfoAsync(); //run the async storage that stores the clicked users info
    } catch (e) {
      console.log("Error : ", e); //error message catch
    }
  }

  getLoggedInUserDetails = async () => { //gets the logged in users token and ID
    try {
      let res = await AsyncStorage.getItem('@logInResponse:token');
      let res2 = await AsyncStorage.getItem('@logInResponse:id');
      console.log("Token is  :", res + "     id is :" + res2);
      this.setState({
        TOKEN: res,
        ID: res2
      });
    } catch (error) {
      console.log("GET TOKEN ERROR : " + error);
    }
  }

  followUser() { //POST method that follows the user that was clicked
    try{
      fetch("http://10.0.2.2:3333/api/v0.0.5/user/"+this.state.followID+"/follow",
      {
        method: 'POST',
        headers: {
          'X-Authorization': this.state.TOKEN //the logged in user's token , so authenticate the follow
        },
      });
      Alert.alert("You are following that user now!")
      console.log("Follow function working! This user id is now being followed :" + this.state.followID )
    }
    catch (error) {
      console.error(error);
    }
  }
  
  storeUserFollowID(user_id) {
    try {
      this.state.followID = user_id
      console.log("Search info  is : " + this.state.followID);
      this.followUser();//runs folow function
    } catch (e) {
      console.log("Set function error : ", e); //error message catch
    }
  }

  showAllUsers() { //search_user function that gets all users with accounts
    return fetch('http://10.0.2.2:3333/api/v0.0.5/search_user/?q=@') //q=@ gets all users
    .then((response) => response.json())
    .then((responseJson) => {
      this.setState({
        isLoading: false,
        userDetails: responseJson,
      });
    })
    .catch((error) => {
      console.error(error);
    });
  }

  componentDidMount() {
    this.showAllUsers(); //gets all the users with accounts
    this.getLoggedInUserDetails(); //gets the token and id of logged in user
  }

  render() {
    if (this.state.isLoading) {
      return (
        <View>
        <ActivityIndicator />
        </View>)
      }

      return (
        <View style={styles.container}>
        <Text style={styles.TitleText}>Current users </Text>
        <FlatList 
        data={this.state.userDetails}
        keyExtractor={({ user_id }) => user_id}
        renderItem={({ item }) =>
        <View style={styles.list}>
        <Text style={styles.ListText}>{'Name :  ' + item.given_name + " " + item.family_name + " Email :" + item.email}</Text>

        <TouchableOpacity style={styles.Button} onPress={() => this.storeUserFollowID(item.user_id)}>
        <Text style={styles.ButtonText2}> FOLLOW</Text>
        </TouchableOpacity>
       
        <TouchableOpacity style={styles.Button} onPress={() => this.storeSearchUserInfo(item.user_id, item.given_name, item.family_name)}> 
        <Text style={styles.ButtonText2}>GO TO PROFILE</Text>
        </TouchableOpacity>
        
        </View>} />
        </View>
      );
    }
  }

  export default AllUsersScreen
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#FFFFFF',
    },

    ButtonText2: {
      color: 'white',
      fontSize: 20,
      textAlign: "center",
      fontWeight: 'bold'
    },

    TitleText: {
      color: 'black',
      fontSize: 28,
      fontWeight: 'bold',
      margin: 5,
      textAlign: "center"
    },

    ListText: {
      color: 'black',
      fontSize: 18,
      textAlign: "center",
      margin: 2,
      padding: 2,
    },

    Button: {
      backgroundColor: '#233947',
      alignItems: 'center',
      margin: 5,
      borderRadius: 15,
      flex: 1,
    },

    list: {
      margin: 5,
      backgroundColor: '#FFFFE0',
      borderRadius: 15,
      borderWidth: 2,
      justifyContent: 'space-around',
      elevation: 1
    },
  });
