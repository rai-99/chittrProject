import React, { Component } from 'react';
import { Text, View, StyleSheet, TextInput, TouchableOpacity, Alert, AsyncStorage, FlatList } from 'react-native';

class MyChits extends Component {
  static navigationOptions = {
    header: false
  }
  constructor(props) {
    super(props);
    this.state = {
      timeStamp: 1583755144,//current time stamp
      chitContent: '',
      TOKEN: '',
      ID: '',
      photoURI: 'https://ibb.co/2sfqZmL',
      isLoading: true,
      recentChits: []
    };
  }

  getLoggedInUserDetails = async () => {
    try {
      let res = await AsyncStorage.getItem('@logInResponse:token');
      let res2 = await AsyncStorage.getItem('@logInResponse:id');
      console.log("Token is  :", res + "     ID is :" + res2);
      this.setState({
        TOKEN: res,
        ID: res2
      });
    } catch (error) {
      console.log("GET TOKEN ERROR : " + error);
    }
  }

  check_textInputs = () => { //checks if the text inputs are empty or not
    const { chitContent} = this.state
    if (chitContent == "") {
      Alert.alert("You can't post nothing ! Please enter something to chitt about!")
      return false
    }
    return true //returns true if text input is not empty
  }


  postChit() { //POST's achit
    if (this.check_textInputs()) { //if statement that only allows post if the text input is not empty
      return fetch("http://10.0.2.2:3333/api/v0.0.5/chits",
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Authorization': this.state.TOKEN, //token used for authentication 
        },
        body: JSON.stringify({
          timestamp: this.state.timeStamp,
          chit_content: this.state.chitContent
        })
      })
      .then((response) => response.json())
      .then((responseJson) => {
        this.setState({
          logInResponse: responseJson,
        });
        this.getRecentChits()
        AsyncStorage.getItem('@clickedUserid');
        Alert.alert("Chit posted!");
      })
      .catch((error) => {
        console.error(error);
      });
    }
  }

  getRecentChits() { //gets all recent chits that have been posted
    return fetch('http://10.0.2.2:3333/api/v0.0.5/chits')
    .then((response) => response.json())
    .then((responseJson) => {
      this.setState({
        isLoading: false,
        recentChits: responseJson,
      });
      console.log("The server response is :" + this.state.recentChits)
    })
    .catch((error) => {
      console.log(error);
    });
  }

  componentDidMount() {
    this.getLoggedInUserDetails()
    this.getRecentChits()
  }


  render() {
    return (
      <View style={styles.container}>
      <Text style={styles.TitleText}>Start chitting</Text>

      <TextInput style={styles.chitText}
      underlineColorAndroid="transparent"
      placeholder={this.state.savedDraft} 
      onChangeText={text => this.setState({ chitContent: text })}
      />

      <TouchableOpacity
      style={styles.Button}
      onPress=
      {
        () => this.postChit()
      }>
      <Text style={styles.ButtonText}> Post</Text>
      </TouchableOpacity>

      <Text style={styles.TitleText}>Recent chits:</Text>
      <FlatList
      refreshing={this.state.isLoading}
      onRefresh={this.getLoggedInUserDetails}
      data={this.state.recentChits.reverse()} //shows most recent post
      keyExtractor={({ chit_id }) => chit_id}
      renderItem={({ item }) => <View style={styles.list}>
      <Text style={styles.ListText}>{item.chit_content}</Text>
      </View>} />
      </View>
    );


  }
}

export default MyChits
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF'
  },

  ButtonText: {
    color: 'white',
    fontSize: 28,
    fontWeight: 'bold'
  },

  TitleText: {
    color: 'black',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: "center",
  },

  ListText: {
    color: 'black',
    borderRadius: 15,
    fontSize: 18,
    textAlign: "center",
    backgroundColor: "#FFFFE0",
    alignItems: 'center',
    margin: 5,
    borderColor: 'black',
    borderWidth: 2,
  },

  chitText: {
    color: 'black',
    fontSize: 18,
    height: 150,
    margin: 10,
    borderRadius: 15,
    backgroundColor: "#FFFFE0",
    borderColor: 'black',
    borderWidth: 2,
  },

  Button: {
    backgroundColor: '#233947',
    borderRadius: 15,
    alignItems: 'center',
    margin: 5,
    height: 50,
  },
});
