import React, { Component } from 'react';
import { Text, View, StyleSheet, FlatList, Alert, ActivityIndicator, TouchableOpacity, AsyncStorage } from 'react-native';

class UserPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      TOKEN: '',
      ID: '',
      followID: 0,
      allMyFollowings: [],
    };
  }

  getLoggedInUserDetails = async () => {//gets the token and id from async storage of the user that is currently logged in
    try {
      let res = await AsyncStorage.getItem('@logInResponse:token');
      let res2 = await AsyncStorage.getItem('@logInResponse:id');
      this.setState({
        TOKEN: res,
        ID: res2
      });
      this.getMyFollowings()//shows all the users that are being followed
      console.log("getLoggedInUserDetails working : " + this.state.ID)
    } catch (error) {
      console.log("getLoggedInUserDetails error : " + error);
    }
  }

  storeUserUnFollowID(id) { //stores the id of the user that was clicked in a state
    try {
      this.state.followID = id
      console.log("Search info  is : " + this.state.followID);
      this.UnfollowUser();//runs the unfollow function

    } catch (e) {
      console.log("Set function error : ", e); //error message catch
    }
  }

  UnfollowUser() {//DELETES the user that was being followed
    try {
      fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.state.followID + "/follow",
      {
        method: 'DELETE',
        headers: {
          'X-Authorization': this.state.TOKEN//token needed for authentication
        },
      });
      Alert.alert("The user has been unfollowed!")
      console.log("Un follow function working! This user id is now been unfollowed :" + this.state.followID)
    }
    catch (error) {
      console.error(error);
    }
  }

  getMyFollowings() {//GETs all the users that this user is currently following
    return fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.state.ID + "/following",
    {
      method: 'GET'
    })
    .then((response) => response.json())
    .then((responseJson) => {
      this.setState({
        isLoading: false,
        allMyFollowings: responseJson,
      });
    })
    .catch((error) => {
      console.log(error);
    });
  }

  componentDidMount() {
    this.getLoggedInUserDetails()


  }

  render() {
    if (this.state.isLoading) {
      return (
        <View>
        <ActivityIndicator />
        </View>)
      }

      return (
        <View style={styles.container}>
        <Text style={styles.TitleText}>My following</Text>
        <FlatList
        refreshing={this.state.isLoading}
        onRefresh={this.getLoggedInUserDetails}
        data={this.state.allMyFollowings}
        keyExtractor={({ user_id }) => user_id}
        renderItem={({ item }) => <View style={styles.list}>
        <Text style={styles.ListText}>{'Name :  ' + item.given_name + " " + item.family_name}</Text>
        <Text style={styles.ListText}>{'Email :  ' + item.email }</Text>
        <TouchableOpacity style={styles.Button} onPress={() => this.storeUserUnFollowID(item.user_id)}>
        <Text style={styles.ButtonText2}>UNFOLLOW</Text>
        </TouchableOpacity>
        </View>} />
        </View>
      );
    }
  }



  export default UserPage

  const styles = StyleSheet.create({
    container: {
      flex: 2,
      backgroundColor: '#FFFFFF'
    },

    ButtonText2: {
      color: 'white',
      fontSize: 20,
      textAlign: "center",
      fontWeight: 'bold'
    },

    TitleText: {
      color: 'black',
      fontSize: 28,
      fontWeight: 'bold',
      margin: 5,
      textAlign: "center"
    },

    ListText: {
      color: 'black',
      fontSize: 18,
      textAlign: "center",
    },

    Button: {
      backgroundColor: '#233947',
      alignItems: 'center',
      margin: 5,
      borderRadius: 15,
      flex: 1,
    },

    list: {
      margin: 5,
      backgroundColor: '#FFFFE0',
      borderRadius: 15,
      borderWidth: 2,
      justifyContent: 'space-around',
      elevation: 1
    },
  });
