import React, { Component } from 'react';
import { Text, View, StyleSheet, TextInput, Alert, TouchableOpacity, AsyncStorage } from 'react-native';

class UserPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      given_name: '',
      family_name: '',
      email: '',
      password: '',
      isLoading: true,
      TOKEN: '',
      ID: ''
    };
  }

  componentDidMount() {
    this.getLoggedInUserDetails() //runs function
  }

  getLoggedInUserDetails = async () => { //gets the token and id from async storage of the user that is currently logged in
    try {
      let res = await AsyncStorage.getItem('@logInResponse:token');
      let res2 = await AsyncStorage.getItem('@logInResponse:id');
      console.log("Token is  :", res + "     id is :" + res2);
      this.setState({
        TOKEN: res,
        ID: res2
      });
    } catch (error) {
      console.log("GetLoggedInUserDetails  error : " + error);
    }
  }

  check_textInputs = () => { //checks if the text inputs are empty or not
    const { given_name, family_name, email, password } = this.state
    if (given_name == "") {
      Alert.alert("Some fields were left empty! Please enter again!")
      return false
    }
    else if (family_name === "") {
      Alert.alert("Some fields were left empty! Please enter again!")
    }
    else if (email === "") {
      Alert.alert("Some fields were left empty! Please enter again!")
    }
    else if (password === "") {
      Alert.alert("Some fields were left empty! Please enter again!")
    }
    return true //returns true if they are not empty
  }

  editAccount() { //PATCH request which updates the users account
    if (this.check_textInputs()) { //if statement that only creates account if all text inputs are not empty
      try {
        fetch("http://10.0.2.2:3333/api/v0.0.5/user/" + this.state.ID,
        {
          method: 'PATCH',
          headers: {
            'X-Authorization': this.state.TOKEN, //logged users token needed for authentication 
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            given_name: this.state.given_name,
            family_name: this.state.family_name,
            email: this.state.email,
            password: this.state.password
          })
        });
        Alert.alert("Your details have been updated!")
        this.props.navigation.navigate('My_Account') //Takes them back to their main account page
        console.log("The user with the id:" + this.state.ID + "has just edtiting their profile!")
      }
      catch (error) {
        console.error(error);
      }
    }
  }

  render() {
    return (
      <View style={styles.container}>
      <Text style={styles.TitleText}> Edit my acount: </Text>
      <TextInput style={styles.ListText}
      underlineColorAndroid="transparent"
      placeholder="Enter your new given name here"
      autoCapitalize="none"
      onChangeText={text => this.setState({ given_name: text })}
      />

      <TextInput style={styles.ListText}
      underlineColorAndroid="transparent"
      placeholder="Enter your new family name here"
      autoCapitalize="none"
      onChangeText={text => this.setState({ family_name: text })}
      />

      <TextInput style={styles.ListText}
      underlineColorAndroid="transparent"
      placeholder="Enter your new email here"
      autoCapitalize="none"
      onChangeText={text => this.setState({ email: text })}
      />

      <TextInput style={styles.ListText}
      underlineColorAndroid="transparent"
      placeholder="Enter your new password here"
      autoCapitalize="none"
      secureTextEntry={true}
      onChangeText={text => this.setState({ password: text })}
      />

      <TouchableOpacity
      style={styles.Button}
      onPress=
      {
        () => this.editAccount()
      }>
      <Text style={styles.ButtonText}> Edit </Text>

      </TouchableOpacity>

      <TouchableOpacity
      style={styles.Button}
      onPress=
      {
        () => this.props.navigation.navigate('My_Account')
      }>
      <Text style={styles.ButtonText}> Go back </Text>
      </TouchableOpacity>
      </View>
    );
  }
}

export default UserPage

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF'
  },

  ButtonText: {
    color: 'white',
    fontSize: 28,
    fontWeight: 'bold'
  },

  TitleText: {
    color: 'black',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: "center",
    margin: 15
  },

  ListText: {
    color: 'black',
    borderRadius: 15,
    fontSize: 18,
    textAlign: "center",
    backgroundColor: "#FFFFE0",
    alignItems: 'center',
    margin: 10,
    borderColor: 'black',
    borderWidth: 2,
  },

  Button: {
    backgroundColor: '#233947',
    padding: 5,
    borderRadius: 15,
    alignItems: 'center',
    margin: 15,
    height: 50,
  },
});
